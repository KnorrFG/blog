(ns peg-thing.core
  (:require [clojure.set :as set])
  (:gen-class))

(declare successful-move prompt-move game-over query-rows prompt-rows)


(defn tri*
  ([] (tri* 0 1))
  ([c-sum n]
    (let [new-sum (+ c-sum n)]
      (cons new-sum (lazy-seq (tri* new-sum (inc n)))))))

(def tri (tri*))


(defn triangular? [n]
  (= n (last (take-while #(<= % n) tri))))


(defn row-tri [n]
  (last (take n tri)))


(defn row-num [pos]
  (inc (count (take-while #(> pos %) tri))))


(defn connect [board max-pos from over to]
  (if (> to max-pos)
    board
    (reduce (fn [nb [from to]]
              (assoc-in nb [from :connections to] over))
            board
            [[from to] [to from]]))) 


(defn connect-right [board max-pos pos]
  (let [neighbour (inc pos)]
    (if-not (or (triangular? pos) (triangular? neighbour))
      (connect board max-pos pos neighbour (inc neighbour))
      board)))


(defn connect-down-left [board max-pos pos]
  (let [row (row-num pos)
        neighbor (+ row pos)
        destination (+ 1 row neighbor)]
          (connect board max-pos pos neighbor destination)))


(defn connect-down-right
    [board max-pos pos]
      (let [row (row-num pos)
                    neighbor (+ 1 row pos)
                            destination (+ 2 row neighbor)]
            (connect board max-pos pos neighbor destination)))


(defn add-pos [board max-pos pos]
  (-> (assoc-in board [pos :pegged] true)
      (connect-right max-pos pos)
      (connect-down-left max-pos pos)
      (connect-down-right max-pos pos)))


(defn new-board [rows]
  (let [max-pos (row-tri rows)]
    (reduce (fn [board pos] (add-pos board max-pos pos))
            {:rows rows}
            (range 1 (inc max-pos)))))


(defn pegged? [board pos] (get-in board [pos :pegged]))
(defn remove-peg [board pos] (assoc-in board [pos :pegged] false))
(defn place-peg [board pos] (assoc-in board [pos :pegged] true))
(defn move-peg [board from to] (place-peg (remove-peg board from) to))


(defn valid-moves [board pos]
  (into {}
        (filter (fn [[destination jumped]]
                  (and (not (pegged? board destination))
                       (pegged? board jumped)))
                (get-in board [pos :connections]))))


(defn valid-move? [board from to]
  (get (valid-moves board from) to))


(defn make-move [board from to]
  (if-let [jumped-pos ( valid-move? board from to )]
    (-> (remove-peg board jumped-pos)
        (move-peg from to))))


(defn can-move?  [board]
  (some (comp not-empty (partial valid-moves board))
        (map first (filter #(get (second %) :pegged) board))))


(def alpha-start 97)
(def alpha-end 123)
(def letters (map (comp str char) (range alpha-start alpha-end)))
(def pos-chars 3)


(defn render-pos [board pos]
  (str (nth letters (dec pos))
       (if (get-in board [pos :pegged])
         "0" 
         "-")))


(defn row-positions [row-num]
  (range (inc (or (row-tri (dec row-num)) 0))
         (inc (row-tri row-num))))


(defn row-padding [row-num rows]
  (let [pad-length (/ (* (- rows row-num) pos-chars) 2)]
    (apply str (take pad-length (repeat " ")))))


(defn render-row
  [board row-num]
  (str (row-padding row-num (:rows board))
       (clojure.string/join " " (map (partial render-pos board) 
                                     (row-positions row-num)))))


(defn print-board
  [board]
  (doseq [row-num (range 1 (inc (:rows board)))]
    (println (render-row board row-num))))


(defn letter->pos [letter]
  (inc (- (int (first letter)) alpha-start)))


(defn get-input ([] (get-input nil))
  ([default]
     (let [input (clojure.string/trim (read-line))]
       (if (empty? input)
         default
         (clojure.string/lower-case input)))))


(defn characters-as-strings [string]
  (->> (vec string)
       (map str)
       (filter #(re-matches #"[a-zA-Z]" %))))


(defn user-entered-invalid-move [board]
  (println "\n!!! That was an invalid move :(\n")
  (prompt-move board))


(defn user-entered-valid-move [board]
  (if (can-move? board)
    (prompt-move board)
    (game-over board)))

  "Announce the game is over and prompt to play again"
(defn prompt-move [board]
  (println "\nHere's your board:")
  (print-board board)
  (println "Move from where to where? Enter two letters:")
  (let [input (map letter->pos (characters-as-strings (get-input)))]
    (if-let [new-board (make-move board (first input) (second input))]
      (user-entered-valid-move new-board)
      (user-entered-invalid-move board))))


(defn game-over [board]
  (let [remaining-pegs (count (filter :pegged (vals board)))]
    (println "Game over! You had" remaining-pegs "pegs left:")
    (print-board board)
    (println "Play again? y/n [y]")
    (let [input (get-input "y")]
      (if (= "y" input)
        (prompt-rows)
        (do
          (println "Bye!")
          (System/exit 0))))))


(defn prompt-empty-peg [board]
  (println "Here's your board:")
  (print-board board)
  (println "Remove which peg? [e]")
  (prompt-move (remove-peg board (letter->pos (get-input "e")))))


(defn prompt-rows []
  (println "How many rows? [5]")
  (let [rows (Integer. (get-input 5))
        board (new-board rows)]
    (prompt-empty-peg board)))


(defn main- [] (promt-rows))
