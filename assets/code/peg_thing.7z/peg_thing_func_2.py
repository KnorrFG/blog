import re
from toolzEx import *
from pyrsistent import PRecord, field, pvector_field, pvector, pmap_field, pmap
import operator as op

alpha_offset = ord('a') - 1

def to_letter(idx):
    return chr(alpha_offset + idx)


def from_letter(letter):
    return ord(letter) - alpha_offset


def tri_num_gen():
    acc = 0
    n = 1
    while True:
        yield acc
        acc += n
        n += 1


tri_nums = ltake(26, tri_num_gen())


def row_num(x):
    return first(i for i, tri in enumerate(tri_nums)
                if tri >= x)


def query_size():
    while True:
        raw = input('How many rows? [5]: ')
        try:
            return int(raw) if raw else 5
        except ValueError:
            pass


def query_valid_start_pos(board):
    while True:
        raw = input(f'which peg should be removed? [e]: ')
        try:
            idx = from_letter(raw) if raw else from_letter('e')
            if 0 < idx <= tri_nums[board.rows]:
                return idx
        except ValueError:
            pass


def query_valid_move(board):
    while True:
        raw = input('Enter a move: ')
        letters = re.findall('[a-z]', raw)
        if len(letters) == 2:
            move = [from_letter(l) for l in letters]
            con = board.find_connection(*move)
            if con:
                return con


def down_right(pos):
    return row_num(pos) + pos + 1


def down_left(pos):
    return row_num(pos) + pos


def right(pos):
    return pos + 1 if not pos in tri_nums else None


Connection = namedtuple('Connection', 'start, end, by')

class Position(PRecord):
    pegged = field(bool, initial=True)
    connections = pvector_field(Connection)
            

@curry
def connections(max_pos, dir_func, pos):
    by = dir_func(pos)
    end = dir_func(by) if by else None
    return [Connection(pos, end, by), 
            Connection(end, pos, by)]\
        if end is not None and end <= max_pos else [None]


class Board(PRecord):
    rows = field(int)
    positions = pmap_field(int, Position)
    
    @staticmethod
    def new(rows):
        cs = connections(tri_nums[rows])
        con_map = thread_last(range(1, tri_nums[rows] + 1),
                (mapcat, juxt(cs(right), cs(down_right), cs(down_left))),
                concat,
                (filter, bool),
                (groupby, X.start))

        return Board(rows=rows, positions=pmap(
            valmap(lambda cons: Position(connections=pvector(cons)),
                   con_map)))

    def __call__(self, pos):
        return self.positions[pos]

    def __str__(self):
        def row_as_str(row):
            return " ".join(
                to_letter(i) + ('o' if self(i).pegged else '-')
                for i in range(tri_nums[row - 1] + 1, tri_nums[row] + 1))

        lines = [row_as_str(row) for row in range(1, self.rows + 1)]
        lpads = reversed([' ' * int(1.5 * i) for i in range(self.rows)])
        return '\n'.join(lpad + row for lpad, row in zip(lpads, lines))

    def toggle(self, pos):
        return self.transform(['positions', pos, 'pegged'], op.not_)

    def valid_move_exists(self):
        return any(self(con.start).pegged and self(con.by).pegged 
                   and (not self(con.end).pegged)
                   for p in self.positions.values() for con in p.connections)

    def make_move(self, start, end, by):
        return self.toggle(start).toggle(end).toggle(by)

    def find_connection(self, start, end):
        try:
            con = first(con for con in self(start).connections
                         if con.end == end)
            if self(con.start).pegged and self(con.by).pegged \
                    and not self(con.end).pegged:
                return con
        except StopIteration:
            return None

    def missing_pegs(self):
        return count(p for p in self.positions.values() if not p.pegged)


@trampoline
def play(board):
    if not board.valid_move_exists():
        return board
    print('\nThis is your board:')
    print(board)
    move = query_valid_move(board)
    return R(board.make_move(*move))


def main():
    size = query_size()
    init_board = Board.new(size)
    print(init_board)
    start_pos = query_valid_start_pos(init_board)
    final_board = play(init_board.toggle(start_pos))
    print('This is your final board state:')
    print(final_board)
    print('You removed', final_board.missing_pegs() - 1, 'pegs')


if __name__ == "__main__":
    main()
