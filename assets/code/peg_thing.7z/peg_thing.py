from dataclasses import dataclass, field
from typing import List
from collections import namedtuple
import re


alpha_offset = ord('a') - 1
Connection = namedtuple('Connection', 'start, to, by')

def to_letter(idx):
    return chr(alpha_offset + idx)


def from_letter(letter):
    return ord(letter) - alpha_offset


def tri_num_gen():
    acc = 0
    n = 1
    while True:
        yield acc
        acc += n
        n += 1


tri_nums = [tri for tri, i in zip(tri_num_gen(), range(26))]


def row_num(x):
    return next(i for i, tri in enumerate(tri_nums)
                if tri >= x)


@dataclass
class Field:
    id: int
    pegged: bool
    connections: List[Connection]


def save_get(seq, pos):
    return seq[pos] if pos < len(seq) else None


class Board:
    def __init__(self, rows):
        self.fields = [Field(i, True, []) for i in range(tri_nums[rows] + 1)]
        self.rows = rows
        self.score = 0
        for f in self.fields:
            Board._connect(f, self.right_of)
            Board._connect(f, self.down_left_of)
            Board._connect(f, self.down_right_of)

    @staticmethod
    def _connect(field, next_field): 
        n = next_field(field)
        nn = next_field(n) if n else None
        if n and nn:
            field.connections.append(Connection(field, nn, n))
            nn.connections.append(Connection(nn, field, n))

    def right_of(self, field):
        if field.id not in tri_nums:
            return save_get(self.fields, field.id + 1)

    def down_left_of(self, field):
        my_row = row_num(field.id)
        return save_get(self.fields, field.id + my_row)

    def down_right_of(self, field):
        my_row = row_num(field.id)
        return save_get(self.fields, field.id + my_row + 1)

    def remove_peg(self, pos):
        self.fields[pos].pegged = False

    def _row_as_str(self, row):
        return " ".join(
            to_letter(i) + ('o' if self.fields[i].pegged else '-')
            for i in range(tri_nums[row - 1] + 1, tri_nums[row] + 1))

    def __str__(self):
        lines = [self._row_as_str(row) for row in range(1, self.rows + 1)]
        lpads = reversed([' ' * int(1.5 * i) for i in range(self.rows)])
        return '\n'.join(
            lpad + row for lpad, row in zip(lpads, lines))

    def valid_connection(self, start, to):
        connections = [c for c in self.fields[start].connections
                       if c.start.id == start and c.to.id == to]
        if len(connections) == 0:
            return False
        c = connections[0]
        if c.start.pegged and c.by.pegged and (not c.to.pegged):
            return c

    def valid_move_exists(self):
        return any(
            con.start.pegged and (not con.to.pegged) and con.by.pegged
            for f in self.fields for con in f.connections)

    def update(self, move):
        move.start.pegged = False
        move.by.pegged = False
        move.to.pegged = True
        self.score += 1


def query_size():
    while True:
        raw = input('How many rows? [5]: ')
        try:
            return int(raw) if raw else 5
        except ValueError:
            pass


def query_valid_start_pos(board):
    while True:
        raw = input(f'which peg should be removed? [e]: ')
        try:
            idx = from_letter(raw) if raw else from_letter('e')
            if 0 < idx <= tri_nums[board.rows]:
                return idx
        except ValueError:
            pass


def query_valid_move(board):
    while True:
        raw = input('Enter a move: ')
        letters = re.findall('[a-z]', raw)
        if len(letters) == 2:
            move = [from_letter(l) for l in letters]
            con = board.valid_connection(*move)
            if con:
                return con


def main():
    size = query_size()
    board = Board(size)
    start_pos = query_valid_start_pos(board)
    board.remove_peg(start_pos)

    while board.valid_move_exists():
        print('This is your board:')
        print(board)
        move = query_valid_move(board)
        board.update(move)

    print('This is your final board state:')
    print(board)
    print('You removed', board.score, 'pegs')

if __name__ == "__main__":
    main()
