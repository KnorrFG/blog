import re
from toolzEx import *


alpha_offset = ord('a') - 1

def to_letter(idx):
    return chr(alpha_offset + idx)


def from_letter(letter):
    return ord(letter) - alpha_offset


def tri_num_gen():
    acc = 0
    n = 1
    while True:
        yield acc
        acc += n
        n += 1


tri_nums = [tri for tri, i in zip(tri_num_gen(), range(26))]


def row_num(x):
    return next(i for i, tri in enumerate(tri_nums)
                if tri >= x)


def query_size():
    while True:
        raw = input('How many rows? [5]: ')
        try:
            return int(raw) if raw else 5
        except ValueError:
            pass


def query_valid_start_pos(board):
    while True:
        raw = input(f'which peg should be removed? [e]: ')
        try:
            idx = from_letter(raw) if raw else from_letter('e')
            if 0 < idx <= tri_nums[board['rows']]:
                return idx
        except ValueError:
            pass


def query_valid_move(board):
    while True:
        raw = input('Enter a move: ')
        letters = re.findall('[a-z]', raw)
        if len(letters) == 2:
            move = [from_letter(l) for l in letters]
            if move[1] in valid_moves_for(board, move[0]):
                return move


def down_right(pos):
    return row_num(pos) + pos + 1


def down_left(pos):
    return row_num(pos) + pos


def right(pos):
    return pos + 1 if not pos in tri_nums else None


def connect(board, pos, dir_func):
    n = dir_func(pos)
    nn = dir_func(n) if n else None
    
    def create_connection(board, start, to, by):
        return assoc_in(board, (start, 'connections', to), by)

    return thread_first(board, 
                       (create_connection, pos, nn, n),
                       (create_connection, nn, pos, n))\
           if nn is not None and nn <= board['maxpos'] else board


def remove_peg(board, pos):
    return assoc_in(board, (pos, 'pegged'), False)


def create_board(size):
    return reduce(lambda b, pos: 
                    thread_first(b, 
                                 (connect, pos, right),
                                 (connect, pos, down_right),
                                 (connect, pos, down_left),
                                 lambda b: assoc_in(b, (pos, 'pegged'), True)),
                  range(1, tri_nums[size] + 1),
                  {'rows': size, 'maxpos': tri_nums[size]})


def as_str(board):
    def row_as_str(row):
        return " ".join(
            to_letter(i) + ('o' if get_in((i, 'pegged'), board) else '-')
            for i in range(tri_nums[row - 1] + 1, tri_nums[row] + 1))

    lines = [row_as_str(row) for row in range(1, board['rows'] + 1)]
    lpads = reversed([' ' * int(1.5 * i) for i in range(board['rows'])])
    return '\n'.join(lpad + row for lpad, row in zip(lpads, lines))


def has_peg(board, pos):
    return get_in([pos, 'pegged'], board)


def valid_moves_for(board, pos):
        return {to: by 
                for to, by in get_in([pos, 'connections'], board).items()
                if not has_peg(board, to) and has_peg(board, by)}
    

def valid_move_exists(board):
    return thread_last(board,
                       (keyfilter, is_a(int)),
                       (valfilter, partial(get, 'pegged')),
                       (map, partial(valid_moves_for, board)),
                       concat,
                       count)


def add_peg(board, pos):
    return assoc_in(board, [pos, 'pegged'], True)


def make_move(board, move):
    return thread_first(
            board,
            (remove_peg, move[0]),
            (remove_peg, get_in([move[0], 'connections', move[1]], board)),
            (add_peg, move[1]))
    
def missing_pegs(board):
    return thread_last(board,
            (keyfilter, is_a(int)),
            (valfilter,  complement(X['pegged'])),
            count)


@trampoline
def play(board):
    if not valid_move_exists(board):
        return board
    print('This is your board:')
    print(as_str(board))
    move = query_valid_move(board)
    print()
    return R(make_move(board, move))

def main():
    size = query_size()
    board = create_board(size)
    print(as_str(board))
    start_pos = query_valid_start_pos(board)
    board = remove_peg(board, start_pos)
    final_board = play(board)
    print('This is your final board state:')
    print(as_str(final_board))
    print('You removed', missing_pegs(final_board) - 1, 'pegs')

if __name__ == "__main__":
    main()
