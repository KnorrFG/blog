import itertools as itt

import commons as cm
from datasheet import Figure, MultiCell, Sheet, render_html

import seaborn as sns
import pandas as pd
import click

from joblib import Parallel, delayed
from toolz import pluck, first
from sklearn.metrics import accuracy_score
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier

def get_optimized_rbfsvm(train_feats, train_labels, test_feats, test_labes):
    return cm.grid_search_optimize_clf(SVC(kernel="rbf", cache_size=500),
                                       train_feats, train_labels, 
                                       test_feats, test_labes,
                                       C=[0.1, 1, 10], 
                                       gamma=[10 ** i for i in range(-3, 2)])


def get_optimized_linsvm(train_feats, train_labels, test_feats, test_labes):
    return cm.grid_search_optimize_clf(SVC(kernel="linear", cache_size=500),
                                       train_feats, train_labels, 
                                       test_feats, test_labes,
                                       C=[0.1, 1, 10])


def get_optimized_rf(train_feats, train_labels, test_feats, test_labes):
    return cm.grid_search_optimize_clf(RandomForestClassifier(n_estimators=100),
                                       train_feats, train_labels, 
                                       test_feats, test_labes,
                                       min_sample_leaf = [2, 5, 10, 20],
                                       max_features = ["sqrt", "log2", None])


def get_optimized_gbm(train_feats, train_labels, test_feats, test_labes):
    return cm.grid_search_optimize_clf(GradientBoostingClassifier(n_estimators=100),
                                       train_feats, train_labels, 
                                       test_feats, test_labes,
                                       learning_rate=[10**x for x in range(-3, 0)],
                                       max_depth=[3, 6, 9])


def name_of_factory(fac_func):
    return fac_func.__name__.split("_")[-1]


def optimize_and_eval_classifier(fac, feats, labels):
    """A row in feats = featvec. The last 100 rows are the eval set,
    the second last 100 rows are the test set, and the rest is the 
    training set."""
    optimized_clf = fac(feats[:-200], labels[:-200], 
                        feats[-200:-100], labels[-200:-100])
    return accuracy_score(labels[-100:], optimized_clf.predict(feats[-100:]))


def process_data_set(dim, data_generator, NRs, clf_factories):
    raw_feats, labels, info = data_generator.generate(dim, 200)
    noise_feats = {nr: cm.corrupt_feats(raw_feats, nr) for nr in NRs}
    cl_results = [(name_of_factory(fac), nr, 
                   optimize_and_eval_classifier(fac, noise_feats[nr], labels))
                   for fac, nr in itt.product(clf_factories, NRs)]
    cl_results_df = pd.DataFrame(cl_results, columns=["clf", "NR", "acc"]).assign(
        dims=dim, dataset=data_generator.name)
    data_infos = [(nr, data_generator.eval_information_level(feats, labels, info))
                  for nr, feats in noise_feats.items()]
    data_info_df = pd.DataFrame(data_infos, columns=["NR", "acc"]).assign(
        dims=dim, dataset=data_generator.name)
    return cl_results_df, data_info_df


def pd_inverse_zip(data):
    return pd.concat(pluck(0, data)), pd.concat(pluck(1, data))


def compute_cl_performance(dims, NRs, repetitions, 
                           data_generators, clf_factories, n_jobs):
    def run():
        results = [process_data_set(dim, data_generator, NRs, clf_factories)
                   for dim, data_generator in itt.product(dims, data_generators)]
        return pd_inverse_zip(results)

    results_repeated = cm.call_n_times_parallel(repetitions, n_jobs, run)
    cl_info, data_info_raw = pd_inverse_zip(results_repeated)
    data_info = cm.aggregate_by_mean_and_ci_str(data_info_raw, 
                                                ["dims", "NR", "dataset"])
    return cl_info, data_info
        

@click.command()
@click.option("--recompute", "-r", is_flag=True)
def main(recompute: bool):
    sheet=Sheet("cl_comp_out")
    sheet << "# Classifier Comparrison"

    dims = [10, 30, 100, 200, 1000]
    NRs = [0, 0.5, 1, 2]
    repetitions = 56
    n_jobs = 7
    data_generators = [cm.LinGenerator(100), cm.LinGenerator(1000),
                       cm.CircleGenerator(100, True), cm.CircleGenerator(1000, True)]
    clf_factories = [
        get_optimized_rbfsvm, 
        get_optimized_linsvm,
        get_optimized_rf,
        get_optimized_gbm
    ]

    cl_results, data_info = sheet.gate_cache(compute_cl_performance, recompute)(
        dims, NRs, repetitions, data_generators, clf_factories, n_jobs)

    sheet << "## Data informativeness"
    for dg in data_generators:
        sheet << "### " + dg.name
        sheet << data_info[data_info.dataset==dg.name].pivot(
            index="NR", columns="dims", values="acc")
    sheet << "### Data example 2D"
    examples_2D = cm.make_example_data_table(NRs, data_generators, 200)
    g = sns.FacetGrid(examples_2D, col="NR", row="dataset", hue="y")
    g.map(sns.scatterplot, "x1", "x2")
    sheet.add_current_figure(scale=1)

    sheet << "## CL Results"
    g = sns.FacetGrid(cl_results, col="NR", row="dataset", hue="clf")
    g.map(sns.lineplot, "dims", "acc", err_style="bars")
    g.add_legend()
    sheet.add_current_figure(scale=1)

    sheet.render()

if __name__ == "__main__":
    main()