import itertools as itt
from collections import namedtuple
from dataclasses import dataclass

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import scipy.stats as ss
from cytoolz import concat, first, mapcat, pipe
from datasheet import Figure, MultiCell, Sheet, render_html
from joblib import Parallel, delayed
from sklearn.metrics import accuracy_score
from sklearn.model_selection import (GridSearchCV, StratifiedKFold,
                                     cross_val_score)
from sklearn.svm import SVC


def decide_linearly(feats, weights, bias):
    return (np.dot(feats, weights) >= bias).astype(np.uint8)


def get_random_linear_data(dimensions, samplesize):
    feats = np.random.normal(size=(samplesize, dimensions))
    weights = np.random.normal(size=(dimensions,))
    return feats, decide_linearly(feats, weights, 0), weights


def circle_center_distance(feats, center):
    return np.sqrt(np.sum((feats - center) ** 2, axis=1))


Circle = namedtuple("Circle", "center, radius")


def decide_with_circle(feats, c: Circle):
    return (circle_center_distance(feats, c.center) < c.radius)\
        .astype(np.uint8)


def get_random_circle_data(dimensions, samplesize, center_at_origin=True):
    feats = np.random.normal(size=(samplesize, dimensions))
    center = 0 if center_at_origin else np.random.normal(size=(dimensions,))
    c = Circle(center, np.median(circle_center_distance(feats, center)))
    return feats, decide_with_circle(feats, c), c


def compute_10_fold_cv_acc(feats, labels, c):
    svm = SVC(c, "linear")
    return cross_val_score(svm, feats, labels, cv=StratifiedKFold(10, True))


def corrupt_feats(feats, noise_ratio):
    if noise_ratio == 0:
        return feats
        
    noise = np.random.normal(size=feats.shape)
    new_feats_unnormalized = feats + noise * noise_ratio
    return new_feats_unnormalized / new_feats_unnormalized.std()


def call_n_times_parallel(n, n_jobs, func, *args, **kwargs):
    return Parallel(n_jobs)(
            delayed(func)(*args, **kwargs) for _ in range(n))


def call_n_times(n, func, *args, **kwargs):
    return [func(*args, **kwargs) for _ in range(n)]


def to_mean_and_ci(vals):
    mean, se = vals.mean(), ss.sem(vals)
    h = se * ss.t.ppf(0.975, vals.size - 1)
    return mean, h


def train_and_eval(train_feats, train_labels, test_feats, test_labels, clf):
    clf.fit(train_feats, train_labels)
    return accuracy_score(test_labels, clf.predict(test_feats))


def aggregate_by_mean_and_ci_str(table, groups):
    return table.groupby(groups).agg(lambda x: "{:.3f}+-{:.3f}"
        .format(*to_mean_and_ci(x))).reset_index()


def set_and_return(target, **attrs):
    for key, val in attrs.items():
        setattr(target, key, val)
    return target


def dict_product(d: dict):
    """Expects a dict, where all values are lists, and returns one dict with identical 
    keys and a single value for each key, for each possible value combination"""
    return (dict(zip(d.keys(), prod)) for prod in itt.product(*d.values()))


def grid_search_optimize_clf(clf, train_feats, train_labels, test_feats, test_labes,
                             **search_space):
    """Evaluates every possible parameter combination given the search space, using
    the test set and returns a classifier that was trained on the training set
    with the best parameter combination""" 
    test_results = [(train_and_eval(train_feats, train_labels,
                                    test_feats, test_labes,
                                    set_and_return(clf, **params)),
                     params) for params in dict_product(search_space)]
    best_params = first(sorted(test_results, key=first, reverse=True))[1]
    return set_and_return(clf, **best_params)\
        .fit(train_feats, train_labels)


def make_example_data_table(NRs, data_generators, sample_size):
    def add_noise_and_make_df(feats, labels, info, nr):
        return pd.DataFrame(corrupt_feats(feats, nr), columns=["x1", "x2"])\
            .join(pd.DataFrame({"y": labels}))

    return pd.concat([add_noise_and_make_df(*dg.generate(2, sample_size), nr).assign(
                            dataset=dg.name, NR=nr) 
                      for nr, dg in itt.product(NRs, data_generators)])


@dataclass
class LinGenerator:
    sample_size: int

    def generate(self, dims, extra_observations=0):
        return get_random_linear_data(dims, self.sample_size + extra_observations)

    def eval_information_level(self, feats, labels, infos):
        return accuracy_score(labels, decide_linearly(feats, infos, 0))

    @property
    def name(self):
        return f"lin ({self.sample_size})"


@dataclass
class CircleGenerator:
    sample_size: int
    center_at_origin: bool

    def generate(self, dims, extra_observations=0):
        return get_random_circle_data(dims, self.sample_size + extra_observations,
                                      self.center_at_origin)

    def eval_information_level(self, feats, labels, infos):
        return accuracy_score(labels, decide_with_circle(feats, infos))

    @property
    def name(self):
        return f"circle ({self.sample_size}, " + \
            f"{'' if self.center_at_origin else 'not '}cented)"
